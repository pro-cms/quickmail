<?php

return [
    'site_title' => 'Quick Mail',
];
