<?php echo e($messagedata); ?>

<?php /**PATH D:\quickmail\resources\views/mails/mail.blade.php ENDPATH**/ ?>