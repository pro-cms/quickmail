<?php $__env->startSection('title', $topic->subject); ?>

<?php $__env->startSection('messenger-content'); ?>
<div class="row">
    <p>
        <?php if($topic->receiverOrCreator() !== null && !$topic->receiverOrCreator()->trashed()): ?>
            <a href="<?php echo e(route('admin.messenger.reply', [$topic->id])); ?>"  class="btn btn-info">
               <i class="fa fa-check-circle" aria-hidden="true"></i>Resend Message
            </a>
        <?php endif; ?>
    </p>
    <div class="col-lg-12">
        <div class="list-group">
            <?php $__currentLoopData = $topic->messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row list-group-item shadow-sm p-3 m-2 rounded-1" style="border-radius: 20px!important">
                    <div class="row">
                        <div class="col col-lg-10">
                           <h5> <strong><?php echo e($message->sender->email); ?></strong></h5>
                        </div>
                        <div class="col col-lg-2">
                           <b> <?php echo e($message->created_at->diffForHumans()); ?></b>
                        </div>
                    </div>
                    <div>
                    </div>
                    <div class="row">
                        <div class="col col-lg-12">
                            <p style="font-size: 16px"><?php echo e($message->content); ?></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.messenger.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\quickmail\resources\views/admin/messenger/show.blade.php ENDPATH**/ ?>